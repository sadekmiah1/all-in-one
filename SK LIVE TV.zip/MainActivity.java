package com.example.sklivetv;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private GridLayout categoryGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categoryGrid = findViewById(R.id.category_grid);

        String[] categories = {"ALL CHANNELS-1", "ALL CHANNELS-2", "BANGLA", "INDIAN BANGLA", "SPORTS", "INDIAN", "CARTOON", "DOCUMENTARY", "ENGLISH", "MUSIC", "ISLAMIC"};
        String[] playlistUrls = {
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Allchannel1.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Allchannel2.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Bangla.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/IndianBangla.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Sports.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Indian.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Cartoon.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Documentary.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/English.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Music.m3u8?v=1.0.1",
                "https://raw.githubusercontent.com/sadekmiah1/all-in-one/main/Islamic.m3u8?v=1.0.1",  // Replace with actual URLs
        };

        int[] categoryLogos = {
                R.drawable.ic_SKLIVETV.png, // ALL CHANNELS-1 logo
                R.drawable.ic_SKLIVETV.png, // ALL CHANNELS-2 logo
                R.drawable.ic_SKLIVETV.png,  // BANGLA logo
                R.drawable.ic_SKLIVETV.png, // INDIAN BANGLA logo
                R.drawable.ic_SKLIVETV.png, // SPORTS logo
                R.drawable.ic_SKLIVETV.png, // INDIAN logo
                R.drawable.ic_SKLIVETV.png, // CARTOON logo
                R.drawable.ic_SKLIVETV.png, // DOCUMENTARY logo
                R.drawable.ic_SKLIVETV.png, // ENGLISH logo
                R.drawable.ic_SKLIVETV.png, // MUSIC logo
                R.drawable.ic_SKLIVETV.png, // ISLAMIC logo
        };

        for (int i = 0; i < categories.length; i++) {
            // Create a new RelativeLayout to hold the button and logo
            RelativeLayout layout = new RelativeLayout(this);
            layout.setLayoutParams(new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT
            ));

            // Create an ImageView for the logo
            ImageView logo = new ImageView(this);
            logo.setImageResource(categoryLogos[i]);
            logo.setLayoutParams(new RelativeLayout.LayoutParams(
                    100, // width
                    100  // height
            ));
            logo.setId(View.generateViewId()); // Generate a unique ID for the logo

            // Create a Button for the category
            Button categoryButton = new Button(this);
            categoryButton.setText(categories[i]);
            categoryButton.setBackgroundColor(0xFF444444); // Default background color
            categoryButton.setTextColor(0xFFFFFFFF);
            categoryButton.setLayoutParams(new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT
            ));
            categoryButton.setPadding(16, 16, 16, 16);
            categoryButton.setOnClickListener(v -> {
                v.setBackgroundColor(0xFFFFD700); // Change border color on click
                openVideoPlayer(playlistUrls[i]);
            });

            // Add the logo and button to the layout
            layout.addView(logo);
            layout.addView(categoryButton);

            // Position the button below the logo
            RelativeLayout.LayoutParams buttonParams = (RelativeLayout.LayoutParams) categoryButton.getLayoutParams();
            buttonParams.addRule(RelativeLayout.BELOW, logo.getId());
            categoryButton.setLayoutParams(buttonParams);

            // Add the layout to the GridLayout
            categoryGrid.addView(layout);
        }
    }

    private void openVideoPlayer(String url) {
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putExtra("VIDEO_URL", url);
        startActivity(intent);
    }
}
