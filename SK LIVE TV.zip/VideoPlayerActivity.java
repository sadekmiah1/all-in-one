package com.example.sklivetv;

import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.offline.DownloadManager;
import com.google.android.exoplayer2.offline.OfflineLicenseHelper;
import com.google.android.exoplayer2.upstream.Cache;
import com.google.android.exoplayer2.upstream.CacheDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultCacheKeyFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource.Factory;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;

import java.io.File;

public class VideoPlayerActivity extends AppCompatActivity {

    private PlayerView playerView;
    private ExoPlayer player;
    private SimpleCache simpleCache;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        playerView = findViewById(R.id.player_view);
        String videoUrl = getIntent().getStringExtra("VIDEO_URL");

        // Initialize cache
        File cacheDir = new File(getCacheDir(), "videoCache");
        simpleCache = new SimpleCache(cacheDir, new NoOpCacheEvictor());

        Cache cache = simpleCache;
        CacheDataSourceFactory cacheDataSourceFactory = new CacheDataSourceFactory(
                cache,
                new Factory()
        );

        // Initialize ExoPlayer
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(videoUrl));
        player.setMediaItem(mediaItem);
        player.prepare();
        player.play();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
        }
        if (simpleCache != null) {
            try {
                simpleCache.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up the cache
        try {
            simpleCache.release();
            // Optionally clear old cache files
            // simpleCache.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
